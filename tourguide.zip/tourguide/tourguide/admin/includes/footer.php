<div class="copyrights">
	 <p>2021 Tourguide Advanced System |  <a href="#">Tourguide Advanced System</a> </p>
</div>	
