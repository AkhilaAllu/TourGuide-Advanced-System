-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2022 at 04:19 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '0e3522a81d8eb25cad13a5218ef97ee1', '2021-06-14 15:22:22');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `BookingId` int(11) NOT NULL,
  `PackageId` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `FromDate` varchar(100) NOT NULL,
  `ToDate` varchar(100) NOT NULL,
  `Comment` mediumtext NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL,
  `CancelledBy` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`BookingId`, `PackageId`, `UserEmail`, `FromDate`, `ToDate`, `Comment`, `RegDate`, `status`, `CancelledBy`) VALUES
(1, 1, 'alluakshaya@gmail.com', '06/10/2021', '06/20/2021', 'Thank you for your service', '2021-06-08 19:01:10', 2, ''),
(5, 2, 'kavya@gmail.com', '06/09/2021', '06/17/2021', 'Good!', '2021-06-08 05:10:24', 1, ''),
(6, 2, 'alluakhila99@gmail.com', '06/10/2021', '06/15/2021', 'Demo', '2021-06-07 21:18:37', 2, 'Akhil'),
(11, 2, 'alluakhila99@gmail.com', '2021-06-15', '2021-06-17', 'thank you for your service', '2021-06-19 07:10:45', 0, NULL),
(12, 1, 'alluakhila99@gmail.com', '2021-06-19', '2021-06-21', 'thank you for your service', '2021-06-19 13:57:01', 0, NULL),
(13, 1, 'alluakhila99@gmail.com', '2021-06-15', '2021-06-21', 'thank you for your service', '2021-06-21 02:44:08', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblenquiry`
--

CREATE TABLE `tblenquiry` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `EmailId` varchar(100) NOT NULL,
  `MobileNumber` char(10) NOT NULL,
  `Subject` varchar(100) NOT NULL,
  `Description` mediumtext NOT NULL,
  `Status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblenquiry`
--

INSERT INTO `tblenquiry` (`id`, `FullName`, `EmailId`, `MobileNumber`, `Subject`, `Description`, `Status`) VALUES
(1, 'Akshaya', 'alluakshaya@gmail.com', '9177266999', 'More about our tour package', 'Manali is a resort and tourist town nestled in the mountains of the Indian state of Himachal Pradesh near the northern end of the Kullu Valley in the Beas River Valley. It is located in the Kullu district, about 270 km north of the state capital, Shimla, 309 km northeast of Chandigarh, and 544 km northeast of Delhi, the national capital. The small town, with a population of 8,096, is the beginning of an ancient trade route to Ladakh and from there over the Karakoram Pass on to Yarkand and Khotan in the Tarim Basin. It is a popular tourist destination and serves as the gateway to Lahaul and Spiti district as well as Leh.', 1),
(2, 'Hunny', 'priyanka@gmail.com', '6300498639', 'Accomodation details', 'Delhi is a destination of every traveller’s dream. Its mystical presence makes it a favourite destination for both domestic as well as international tourists. Delhi has witnessed rise and fall of many great empires, glimpse of which is still present in its monuments and streets that have been walked and inhabited by great warriors since decades.', 1),
(3, 'samatha', 'demo@gmail.com', '9999999999', 'More places to visit in vizag', 'Simhachalam Temple. The Simhachalam Temple in Visakhapatnam is one of the most popular places to visit.Rama Krishna Beach. A famous beach popular among locals and tourists alike is the Ramakrishna Beach, named after Ramakrishna Mission ashram located nearby. INS Kurusura Submarine Museum.\r\nRishikonda Beach. Araku Valley.', 1),
(4, 'Vyshnavi', 'vyshnavi@gmail.com', '4747474747', 'few more details', 'Kerala is a state on the Malabar Coast of India. It was formed on 1 November 1956, following the passage of the States Reorganisation Act, by combining Malayalam-speaking regions of the erstwhile regions of Cochin, Malabar, South Canara, and Travancore. Spread over 38,863 km², Kerala is the twenty-first largest Indian state by area. It is bordered by Karnataka to the north and northeast, Tamil Nadu to the east and south, and the Lakshadweep Sea to the west. With 33,406,061 inhabitants as per the 2011 Census, Kerala is the thirteenth-largest Indian state by population. It is divided into 14 districts with the capital being Thiruvananthapuram. Malayalam is the most widely spoken language and is also the official language of the state.', 1),
(5, 'ERF', 'alluakhila99@gmail.com', '7032385399', 'trip details', 'RRTRR', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblissues`
--

CREATE TABLE `tblissues` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `Issue` varchar(100) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblissues`
--

INSERT INTO `tblissues` (`id`, `UserEmail`, `Issue`, `Description`, `PostingDate`, `AdminRemark`) VALUES
(2, 'priyanka@gmail.com', 'Cancellation', 'we want to visit it in next month.\r\nThank you for your service!', '2021-06-11 22:03:33', 'Ok! Thank you !'),
(5, 'alluakhila99@gmail.com', 'Cancellation', 'Not interested now', '2021-06-11 05:12:14', 'ok Thank you !');

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `type`, `detail`) VALUES
(3, 'aboutus', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Tourguide Advanced System project developers 2021</span>'),
(11, 'contact', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Contact to the mailid : alluakhila99@gmail.com</span>');

-- --------------------------------------------------------

--
-- Table structure for table `tbltourpackages`
--

CREATE TABLE `tbltourpackages` (
  `PackageId` int(11) NOT NULL,
  `PackageName` varchar(200) NOT NULL,
  `PackageType` varchar(150) NOT NULL,
  `PackageLocation` varchar(100) NOT NULL,
  `PackagePrice` int(11) NOT NULL,
  `PackageDetails` mediumtext NOT NULL,
  `PackageImage` varchar(100) NOT NULL,
  `Creationdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltourpackages`
--

INSERT INTO `tbltourpackages` (`PackageId`, `PackageName`, `PackageType`, `PackageLocation`, `PackagePrice`, `PackageDetails`, `PackageImage`, `Creationdate`) VALUES
(1, 'Manali Trip ', 'General', 'Kullu Manali India', 20000, '\"Manali is a resort and tourist town nestled in the mountains of the Indian state of Himachal Pradesh near the northern end of the Kullu Valley in the Beas River Valley. It is located in the Kullu district, about 270 km (168 mi) north of the state capital, Shimla, 309 km (192 miles) northeast of Chandigarh, and 544 km (338 miles) northeast of Delhi, the national capital. The small town, with a population of 8,096, is the beginning of an ancient trade route to Ladakh and from there over the Karakoram Pass on to Yarkand and Khotan in the Tarim Basin. It is a popular tourist destination and serves as the gateway to Lahaul and Spiti district as well as Leh.\"', 'Manali.jpg', '2021-06-14 14:23:44'),
(2, 'Kerala', 'Family and Couple', 'Kerala', 5000, ' Kerala is among the most beautiful tourist destinations in India, and it has something to offer all year-round. However, the best Kerala season for tourism is during the winter season, from December to February. Many tourists also come to Kerala in October-November, during the north east monsoon season.\r\n\r\nKerala tourism season, thus, begins in October and ends towards March. It is the peak season; and the best time to visit Kerala.\r\n\r\n', 'images.jpg', '2021-06-13 22:39:37'),
(3, 'Hyderabad', 'General', 'Hyderabad Telangana', 4000, ' The city of smiles, of lights, of a thousand faces, endearingly called the Pearl City, Hyderabad offers a variety of tourist attractions ranging from Heritage monuments, Lakes and Parks, Gardens and Resorts, Museums to delectable cuisine and a delightful shopping experience. To the traveller, Hyderabad offers a fascinating panorama of the past, with a richly mixed cultural and historical tradition spanning 400 colourful years. Some of the tourist attractions include.', 'Hyderabad.jpg', '2021-06-13 22:42:10'),
(4, 'Vizag', 'General', 'Vizag AndhraPradesh', 3000, 'Visakhapatnam , formerly known as Vizagapatam (also known as Vizag) is the proposed executive capital of the Indian state of Andhra Pradesh. It is also the most populated and largest city of Andhra Pradesh. It lies between the Eastern Ghats and the coast of the Bay of Bengal. It is the second largest city in the east coast of India after Chennai.', 'vizag.jpg', '2021-06-12 15:09:59'),
(5, 'Delhi', 'Family', 'Delhi India', 20000, 'You can’t define Delhi in just a few words. The city is too dynamic for that. It’s rich history saturated with old stories reflects in beautiful heritage buildings tucked around the sprawling city. The dusty patina of the old stonewalls gives a rumbling beauty to the city landscape and one can almost hear the sounds of the past echoing.\r\n\r\nThis city is a haven for gourmets. Right from traditional Mughlai nooks tucked behind Jama Masjid to fancy world class restaurants, Delhi has something for everyone. It’s vibrancy extends to it’s handlooms as well, filling the noisy bustling bazaars with a colorful display of local merchandise. Delhi is an exotic vivid destination deserving to be on your itinerary.', 'delhi.jpg', '2021-06-12 15:15:30'),
(7, 'Hampi', 'General', 'Karnataka', 5000, 'dssf', 'Hampi.jpg', '2021-06-19 07:11:43');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `MobileNumber` char(10) NOT NULL,
  `EmailId` varchar(70) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Password`, `RegDate`) VALUES
(1, 'Akshaya', '9177266999', 'alluakhshaya99@gmail.com', '5c428d8875d2948607f3e3fe134d71b4', '2021-06-12 10:38:17'),
(2, 'Hunny', '6300498639', 'priyanka@gmail.com', '5c428d8875d2948607f3e3fe134d71b4', '2021-06-10 10:50:48'),
(3, 'samatha', '9999999999', 'demo@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2021-06-11 07:17:44'),
(4, 'Vyshnavi', '4543534534', 'vyshnavi@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2021-06-09 07:43:23'),
(5, 'Kavya', '1314145', 'kavya@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '2021-06-11 10:32:18'),
(6, 'Akhila', '7032385399', 'alluakhila99@gmail.com', '5ddeaa03076b3f573efec2f3da5c6e7c', '2021-06-10 04:06:10'),
(14, 'gtdf', '123', 'admin', '0e3522a81d8eb25cad13a5218ef97ee1', '2021-06-19 14:04:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`BookingId`);

--
-- Indexes for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissues`
--
ALTER TABLE `tblissues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltourpackages`
--
ALTER TABLE `tbltourpackages`
  ADD PRIMARY KEY (`PackageId`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmailId` (`EmailId`),
  ADD KEY `EmailId_2` (`EmailId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `BookingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblissues`
--
ALTER TABLE `tblissues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbltourpackages`
--
ALTER TABLE `tbltourpackages`
  MODIFY `PackageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
